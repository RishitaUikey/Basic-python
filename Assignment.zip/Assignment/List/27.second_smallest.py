# Write a Python program to find the second smallest number in a list.

list = [21,12,8,15,9,11]
sort_list=sorted(list)
print("the second smallest number in a list is",sort_list[1])
