# Write a Python program to get the largest number from a list.
l=[2,9,4,5,8,6,12,16]
print(max(l))