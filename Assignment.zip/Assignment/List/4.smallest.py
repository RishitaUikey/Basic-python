# Write a Python program to get the smallest number from a list.
l=[2,3,4,5,8,65,34]
print(min(l))