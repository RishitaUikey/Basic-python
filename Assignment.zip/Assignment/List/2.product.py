#  Write a Python program to multiply all the items in a list.
l= [1,2,3,4,5]
product=1
for i in l:
    product*=i
print(product)