# Write a Python program to get a variable with an identification number or string.

x=50
print(id(x),x)