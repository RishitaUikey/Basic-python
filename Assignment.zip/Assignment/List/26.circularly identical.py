# Write a Python program to check whether two lists are circularly identical.

list1=[1,0,10,10,0,0,10]
list2=[10,10,0,0,10,1,0]
list3=[10,1,0,10,0,0,10]

    