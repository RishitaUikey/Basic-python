#Write a Python program to select an item randomly from a list.
import random

list=[11,2,65,7,6,54,32,65,76]
new_list=random.choice(list)
print(new_list)
