# Write a Python program to create a list of empty dictionaries.

a = 8
List = [{} for _ in range(a)]
print(List)