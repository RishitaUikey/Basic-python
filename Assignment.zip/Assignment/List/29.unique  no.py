# Write a Python program to get unique values from a list.

my_list=[90,60,40,10,20,60,50,40,30,70]
l=list(set(my_list))
print(l)