# Write a Python program to generate all permutations of a list in Python.

import itertools
print(list(itertools.permutations([1, 2, 3])))