# Write a Python program to find common items in two lists.

list1=[1,2,3,4,5,6]
list2=[5,6,7,8,9,10]
list=[]
for i in list1:
    if i in list2:
        list1==list2
        list.append(i)
print(list)