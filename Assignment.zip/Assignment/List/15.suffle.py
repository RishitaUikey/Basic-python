# Write a Python program to shuffle and print a specified list.

