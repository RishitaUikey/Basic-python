# Write a Python program to find the second largest number in a list.

list=[21,12,8,15,9,11,43,98,76]
sort_list=sorted(list,reverse=True)
print("the second smallest number in a list is",sort_list[1])

