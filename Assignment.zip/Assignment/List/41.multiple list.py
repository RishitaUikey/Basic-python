# Write a Python program to create multiple lists.

list1=[12,3,4,68,6,765,1]
list2=[32,54,76,8,9,23]
list3=[67,23,5,43,12,65,87]

print("List1:",list1)
print("List2:",list2)
print("List3:",list3)