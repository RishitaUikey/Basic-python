# Write a Python program to convert a pair of values into a sorted unique array.

L = [(1, 2), (3, 4), (1, 2), (5, 6), (7, 8), (1, 2), (3, 4), (3, 4), (7, 8), (9, 10),(11,12),(13,14),(15,16)]
print("Original List: ", L)
print("Sorted Unique Data:", sorted(set().union(*L)))