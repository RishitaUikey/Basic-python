# Write a Python program to split a list into different variables.

# Sample list
my_list = [(1, 2, 3),('a','b','c','d'),('apple','banana','mango','orange')]

# Unpack the list into separate variables
var1, var2, var3 = my_list

# Print the variables
print("Variable 1:", var1)
print("Variable 2:", var2)
print("Variable 3:", var3)
