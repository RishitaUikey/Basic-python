# Write a Python program to remove duplicates from a list.

l =[1,2,3,4,5,1,5,6,2]
s = set(l)
print(list(s))