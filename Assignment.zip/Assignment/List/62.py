# Write a Python program to print a list of space-separated elements.

a = [10,20,30,40,50,60,70,80,90,100]
print(*a)