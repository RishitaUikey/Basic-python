# Write a Python program to concatenate elements of a list.


list=["red", "orange", "blue", "white"]
concatenate_string='-'.join(list)
print(concatenate_string)