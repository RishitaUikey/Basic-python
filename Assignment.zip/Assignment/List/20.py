# Write a Python program to access the index of a list.

my_list = ['a', 'b', 'c', 'd', 'e']
for index, value in enumerate(my_list):
    print(f"Index of '{value}': {index}")
