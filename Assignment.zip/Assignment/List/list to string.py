# Write a Python program to convert a list of characters into a string.

list=['P','Y','T','H','O','N']
string=''.join(list)
print(string)