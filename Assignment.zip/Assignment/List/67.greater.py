# Write a Python program to find all the values in a list that are greater than a specified number.

list1=[87,98,123,764,196,654,70,63,1,864]
list2=[]
for i in list1:
    if i>100:
        list2.append(i)
print(list2)
    
