l= [1,2,3,4,5]
product=1
for i in l:
    product*=i
print(product)