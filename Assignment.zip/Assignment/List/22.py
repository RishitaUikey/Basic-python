# Write a Python program to find the index of an item in a specified list.

num = [20, 37, 54, -81]
print(num.index(54))