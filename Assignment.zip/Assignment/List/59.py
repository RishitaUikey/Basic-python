# Write a Python program to check whether the n-th element exists in a given list.

x = [11,12,13,14,15,16,17,18,19,20]
len = len(x) - 1
print(x[len])