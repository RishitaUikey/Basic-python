# Write a Python program to convert a string to a list.


x = "Hello Everyone ! Welcome to the coding world ."
list= x.split()
print("List of words:", list)
