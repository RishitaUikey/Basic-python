# Write a Python program to append a list to the second list.

list1=[1,2,3,4]
list2=['red','blue','green']
list2.append(list1)
print(list2)