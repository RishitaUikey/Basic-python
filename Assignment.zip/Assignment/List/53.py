#  Write a Python program to create a list with infinite elements.

import itertools

c = itertools.count()

print(next(c))

print(next(c))

print(next(c))

print(next(c))

print(next(c)) 




