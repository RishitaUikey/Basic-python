# Write a Python program to iterate over dictionaries using for loops.

my_dict = {'apple': 3, 'banana': 5, 'orange': 2}
for key, value in my_dict.items():
    print(key, '-->', value)
