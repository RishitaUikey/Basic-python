# Write a Python program to sort a given dictionary by key.

original_dict = {'b': 3, 'a': 1, 'c': 2}
sorted_dict = dict(sorted(original_dict.items()))
print("Sorted dictionary by key:")
print(sorted_dict)
