# Write a  Python program to get the key, value and item in a dictionary.

my_dict = {'a': 1, 'b': 2, 'c': 3}
for key, value in my_dict.items():
    print("Key:", key)
    print("Value:", value)
    print("Item:", (key, value))
    print()
