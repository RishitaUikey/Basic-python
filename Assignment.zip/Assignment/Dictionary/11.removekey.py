''' Write a Python program to remove a key from a dictionary.'''

x={'a':37,'b':92,'c':56,'d':89}
x.pop('a')
print(x)
