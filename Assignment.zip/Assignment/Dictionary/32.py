# Write a Python program to print a dictionary line by line.

my_dict = {'a': 1, 'b': 2, 'c': 3}
for key, value in my_dict.items():
    print(key, ":", value)
