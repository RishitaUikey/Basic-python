'''Write a Python script to merge two Python dictionaries.'''

x={'Name':'Rishita','Age':21,'College':'YCCE'}
y={'Branch':'CSE','DOB':28-10-2002}
x.update(y)
print(x)