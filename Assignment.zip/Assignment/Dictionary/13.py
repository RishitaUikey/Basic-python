# Write a Python program to map two lists into a dictionary.

keys = ['a', 'b', 'c', 'd']
values = [1, 2, 3, 4]
result_dict = dict(zip(keys, values))
print("Resulting dictionary:", result_dict)
