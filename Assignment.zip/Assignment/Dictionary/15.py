# Write a Python program to get the maximum and minimum values of a dictionary.

original_dict = {'a': 10, 'b': 5, 'c': 15, 'd': 20}
max_value = max(original_dict.values())
min_value = min(original_dict.values())
print("Maximum value:", max_value)
print("Minimum value:", min_value)
