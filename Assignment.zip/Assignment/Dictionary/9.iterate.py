'''Write a Python program to iterate over dictionaries using for loops.'''

x={'c':21,'a':19,'d':37,'f':15}
for key,value in x.items():
    print(f"{key} corresponds to {value}")
  