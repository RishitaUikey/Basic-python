'''Write a Python program to sum all the items in a dictionary.'''

x={'a':37,'b':92,'c':56,'d':89}
sum=sum(x.values())
print(sum)