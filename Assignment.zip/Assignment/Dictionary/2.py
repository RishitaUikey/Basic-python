'''Write a Python script to add a key to a dictionary.

Sample Dictionary : {0: 10, 1: 20}
Expected Result : {0: 10, 1: 20, 2: 30}'''

y = {0: 10, 1: 20}
y[2]=30
print(y.items())
