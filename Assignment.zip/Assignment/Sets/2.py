# Write a Python program to iterate over sets.

set = {1, 2, 3, 4, 5}
print("Elements of the set:")
for i in set:
    print(i)
