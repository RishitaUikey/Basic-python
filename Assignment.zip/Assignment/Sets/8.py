# Write a Python program to create set difference.

s1 = {1, 2, 3, 4, 5}
s2 = {4, 5, 6, 7, 8}
difference = s1.difference(s2)
print("Set difference (set1 - set2):", difference)
