# Write a Python program to find the length of a set.

set = {3, 8, 1, 6, 9, 2, 7}
set_length = len(set)
print("Length of the set:", set_length)
