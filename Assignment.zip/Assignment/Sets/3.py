# Write a Python program to add member(s) to a set.

set = {1, 2, 3}
set.add(4)
set.update([5, 6, 7])
print("Updated set:", set)
