# Write a  Python program to check if a given value is present in a set or not.

set = {1, 2, 4, 6, 9, 7, 8}
value = 5
if value in set:
    print(f"{value} is present in the set.")
else:
    print(f"{value} is not present in the set.")
