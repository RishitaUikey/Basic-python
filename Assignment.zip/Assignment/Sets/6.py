# Write a Python program to create an intersection of sets.

s1 = {1, 2, 3, 4, 5}
s2 = {4, 5, 6, 7, 8}
intersection = s1.intersection(s2)
print("Intersection of set1 and set2:", intersection)
