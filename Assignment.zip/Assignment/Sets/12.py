# Write a Python program to remove all elements from a given set.

set = {1, 2, 3, 4, 5}
set.clear()
print("Set after removing all elements:", set)
