# Write a Python program to create a set.


m = {1, 2, 3, 4, 5}
print("Set elements:", m)
