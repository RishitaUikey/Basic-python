# Write a Python program to create a symmetric difference.

s1 = {1, 2, 3, 4, 5}
s2 = {4, 5, 6, 7, 8}
symmetric_difference = s1.symmetric_difference(s2)

# Displaying the symmetric difference
print("Symmetric difference:", symmetric_difference)
