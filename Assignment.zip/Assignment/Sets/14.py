# Write a Python program to find the maximum and minimum values in a set.

set = {3, 8, 1, 6, 9, 2, 7}

max_value = max(set)
min_value = min(set)

print("Maximum value:", max_value)
print("Minimum value:", min_value)
