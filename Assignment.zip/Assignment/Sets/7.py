# Write a Python program to create a union of sets.

s1 = {1, 2, 3, 4, 5}
s2 = {4, 5, 6, 7, 8}
union = s1.union(s2)
print("Union of set1 and set2:", union)
