# Write a Python program that accepts a word from the user and reverses it.
x = str(input("Enter the word ="))
print(x[-1::-1])

