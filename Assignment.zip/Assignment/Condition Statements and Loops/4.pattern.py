''' Write a Python program to construct the following pattern, using a nested for loop.

* 
* * 
* * * 
* * * * 
* * * * * 
* * * * 
* * * 
* * 
*   '''
x=5
for i in range(1,x+1):
    for j in range(1,i+3):
        print(" * ",end="")
    print()
        

    
    
