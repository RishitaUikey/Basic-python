'''Write a Python function to sum all the numbers in a list.
Sample List : (8, 2, 3, 0, 7)
Expected Output : 20'''

numbers=[8, 2, 3, 0, 7]
sum_all=sum(numbers)
print("sum all the numbers in a list is ",sum_all)