'''Write a  Python class to reverse a string word by word.
Input string : 'hello . py'
Expected Output : '. py hello' '''

