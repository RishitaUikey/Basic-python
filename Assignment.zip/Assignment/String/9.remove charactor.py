'''Write a Python program to remove the nth index character from a nonempty string.'''

str1 = 'Python'
n = 3
result = str1[0:3] + str1[4:]
print(result)
