# Write a Python program to sort a string lexicographically.

str1 = input("Enter the string : ")

print(sorted(str1))