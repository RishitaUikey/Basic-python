'''Write a Python program to get the last part of a string before a specified character.
https://www.w3resource.com/python-exercises
https://www.w3resource.com/python  '''


str1 = 'https://www.w3resource.com/python-exercises'
print(str1.rsplit('-')[0])  # rsplit is used to split the output from right and [0] to get remaining output except after '-'




