# Write a Python program to calculate the length of a string.

l=[2,9,4,5,8,6,12,16,5,8,9]
print(len(l))