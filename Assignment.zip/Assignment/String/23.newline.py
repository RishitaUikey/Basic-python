# Write a Python program to remove a newline in Python.

str1 = input("Enter the string: \n")
str1.rstrip('\n')
print(str1)
             