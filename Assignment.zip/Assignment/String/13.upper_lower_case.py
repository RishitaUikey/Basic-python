#  Write a Python script that takes input from the user and displays that input back in upper and lower cases.

str = input("Enter the string: ")
print("input back in upper case: ",str.upper())
print("input back in lower case: ",str.lower())
