'''Write a Python function to sum all the numbers in a list.
Sample List : (8, 2, 3, 0, 7)
Expected Output : 20 '''

def sum_list(Slist):

    return sum(Slist)
list1 = [8,2,3,0,7]
sum_all = sum_list(list1)
print("sum all the numbers in a list: ",sum_all)